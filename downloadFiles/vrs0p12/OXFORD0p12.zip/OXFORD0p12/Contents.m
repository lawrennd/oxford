% OXFORD toolbox
% Version 0.12		Monday 06 Mar 2006 at 15:15
% Copyright (c) 2006 Neil D. Lawrence
% 
% DEMCOVFUNCSAMPLE Sample from some different covariance functions.
% DEMDIGITSMANIFOLD Project and rotate an artificial data set of handwritten digits. 
% DEMGPSCOV2D Simple demonstration of sampling from a covariance function.
% DEMGPSAMPLE Simple demonstration of sampling from a covariance function.
% DEMMANIFOLD Show rotation of the digit 6/9.
% DEMMANIFOLDPRINT Print the principal components of the artificial digits data set.
% DEMSTICKRESULTS1 Show the results of stick man optimisations interactively.
% PREPDEMMANIFOLD Read in handwritten 6 and prepare for visualisation.
