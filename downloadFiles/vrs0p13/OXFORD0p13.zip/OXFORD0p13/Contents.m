% OXFORD toolbox
% Version 0.13		Thursday 22 Jun 2006 at 01:05
% Copyright (c) 2006 Neil D. Lawrence
% 
% DEMSTICKRESULTS Show the results of stick man optimisations interactively.
% DEMMANIFOLD Show rotation of the digit 6/9.
% DEMDIGITSMANIFOLD Project and rotate an artificial data set of handwritten digits. 
% DEMCOVFUNCSAMPLE Sample from some different covariance functions.
% DEMKERNELIMAGES Create plots of some covariance functions
% DEMGPCOV2D Simple demonstration of sampling from a covariance function.
% DEMGPSAMPLE Simple demonstration of sampling from a covariance function.
% DEMINTERPOLATION Demonstrate Gaussian processes for interpolation.
% DEMMANIFOLDPRINT Print the principal components of the artificial digits data set.
% PREPDEMMANIFOLD Read in handwritten 6 and prepare for visualisation.
% DEMREGRESSION Demonstrate Gaussian processes for regression.
% DEMGPLVMTALK Show demos for GP-LVM talk in order.
% DEMOPTIMISEKERN Shows that there is an optimum for the kernel length scale.
