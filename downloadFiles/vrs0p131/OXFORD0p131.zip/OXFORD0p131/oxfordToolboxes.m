
% OXFORDTOOLBOXES Toolboxes required for the Oxford demos.
%
%	Description:
%	

%	Copyright (c) 2007 Neil D. Lawrence
% 	oxfordToolboxes.m version 1.3

importLatest('netlab');
importLatest('ndlutil');
importLatest('kern');
importLatest('noise');
importLatest('prior');
importLatest('optimi');
importLatest('mocap');
importLatest('fgplvm');
importLatest('gp');
importLatest('datasets');
importLatest('mltools');
