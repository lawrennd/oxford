% OXFORD toolbox
% Version 0.131		14-Feb-2007
% Copyright (c) 2007 Neil D. Lawrence
% 
% DEMBACKMAPPING Show difference in latent variable models that use a forward and reverse mapping.
% DEMCOVFUNCSAMPLE Sample from some different covariance functions.
% DEMDIGITSMANIFOLD Project and rotate an artificial data set of handwritten digits. 
% DEMDYNAMICSARROWPLOT Prepare an plot for arrow between two latent space plots.
% DEMGPCOV2D Simple demonstration of sampling from a covariance function.
% DEMGPLVMTALK Show demos for GP-LVM talk in order.
% DEMGPSAMPLE Simple demonstration of sampling from a covariance function.
% DEMINTERPOLATION Demonstrate Gaussian processes for interpolation.
% DEMKERNELIMAGES Create plots of some covariance functions
% DEMMANIFOLD Show rotation of the digit 6/9.
% DEMMANIFOLDPRINT Print the principal components of the artificial digits data set.
% DEMOPTIMISEKERN Shows that there is an optimum for the kernel length scale.
% DEMREGRESSION Demonstrate Gaussian processes for regression.
% DEMSIX Produce figures of the handwritten six and rotated versions.
% DEMSTICKRESULTS Show the results of stick man optimisations interactively.
% OXFORDTOOLBOXES Toolboxes required for the Oxford demos.
% PREPDEMMANIFOLD Read in handwritten 6 and prepare for visualisation.
