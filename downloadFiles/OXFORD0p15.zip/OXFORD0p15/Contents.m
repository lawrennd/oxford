% OXFORD toolbox
% Version 0.15		01-Apr-2008
% Copyright (c) 2008, Neil D. Lawrence
% 
, Neil D. Lawrence
% PREPDEMMANIFOLD Read in handwritten 6 and prepare for visualisation.
% DEMDIGITSMANIFOLD Project and rotate an artificial data set of handwritten digits. 
% DEMSIX Produce figures of the handwritten six and rotated versions.
% DEMLEASTSQUARESREGRESS Demonstrate Least Squares Regression with RBF Bases.
% DEMINTERPOLATION Demonstrate Gaussian processes for interpolation.
% OXFORDTOOLBOXES Toolboxes required for the Oxford demos.
% DEMDYNAMICSARROWPLOT Prepare an plot for arrow between two latent space plots.
% DEMBAYESREGRESS Demonstrate Bayesian Regression with RBF Bases.
% DEMICML07 Show results for HGPLVM ICML talk.
% EPPOINTUPDATE Demonstrate in one-D an EP point inclusion.
% DEMMANIFOLD Show rotation of the digit 6/9.
% DEMCOVFUNCSAMPLE Sample from some different covariance functions.
% DEMSTICKRESULTS Show the results of stick man optimisations interactively.
% DEMMANIFOLDPRINT Print the principal components of the artificial digits data set.
% DEMGPCOV2D Simple demonstration of sampling from a covariance function.
% DEMGPSAMPLE Simple demonstration of sampling from a covariance function.
% DEMREGRESSION Demonstrate Gaussian processes for regression.
% DEMOPTIMISEKERN Shows that there is an optimum for the kernel length scale.
% DEMBACKMAPPING Show difference in latent variable models that use a forward and reverse mapping.
% BAYESCOMPUTEBASES Computes the bases functions for the simple Bayesian regression.
% DEMKERNELIMAGES Create plots of some covariance functions
% DEMGPLVMTALK Show demos for GP-LVM talk in order.
