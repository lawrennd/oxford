function y = bayesComputeBases(x, centres, width)

% BAYESCOMPUTEBASES Computes the bases functions for the simple Bayesian regression.
%
%	Description:
%
%	RETURN = BAYESCOMPUTEBASES(X, CENTRES, WIDTHS) computes the bases
%	functions (RBF) for a simple Bayesian regression.
%	 Returns:
%	  RETURN - values of the bases functions for the given input data.
%	 Arguments:
%	  X - input data.
%	  CENTRES - centres of the bases functions.
%	  WIDTHS - widths of the bases funcitons.
%	COPYIGHT : Neil D. Lawrence, 2008
%	
%
%	See also
%	DEMBAYESREGRESS
% 	bayesComputeBases.m version 1.1

  
y = exp(-dist2(x, centres')/(2*width*width));