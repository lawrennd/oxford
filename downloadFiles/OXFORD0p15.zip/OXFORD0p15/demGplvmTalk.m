
% DEMGPLVMTALK Show demos for GP-LVM talk in order.
%
%	Description:
%	% 	demGplvmTalk.m version 1.3


colordef white

disp('Ready ... rotation of digit.')
disp('demManifold')
r = input('Type ''R'' to run or ''S'' to skip: ', 's');
switch r
  case {'r', 'R'}
   close all
   clear all
   demManifold
 otherwise
end
disp('Ready ... stickman results.')
disp('demStickResults')
r = input('Type ''R'' to run or ''S'' to skip: ', 's');
switch r
  case {'r', 'R'}
   close all
   clear all
   demStickResults
 otherwise
end
disp('load demWalkRun1.mat')
disp(['hgplvmHierarchicalVisualise(model, visualiseNodes, depVisData'])
r = input('Type ''R'' to run or ''S'' to skip: ', 's');
switch r
 case {'r', 'R'}
  close all
  clear all
  % Load model
  load demWalkRun1
  % Display results
  hgplvmHierarchicalVisualise(model, visualiseNodes, depVisData);

 otherwise
end
disp('press any key to tidy up.')
pause
clear all
close all
