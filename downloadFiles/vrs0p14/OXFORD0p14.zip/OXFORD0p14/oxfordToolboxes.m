
% OXFORDTOOLBOXES Toolboxes required for the Oxford demos.
%
%	Description:
%	

%	Copyright (c) 2007 Neil D. Lawrence
% 	oxfordToolboxes.m version 1.4

importLatest('netlab');
importLatest('ndlutil');
importTool('kern', 0.166);
importLatest('noise');
importLatest('prior');
importLatest('optimi');
importLatest('mocap');
importLatest('fgplvm');
importLatest('gp');
importLatest('datasets');
importLatest('mltools');
importLatest('hgplvm');