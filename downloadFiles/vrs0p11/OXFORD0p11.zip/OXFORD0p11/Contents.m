% OXFORD toolbox
% Version 0.11		Wednesday 01 Feb 2006 at 08:09
% Copyright (c) 2006 Neil D. Lawrence
% 
% DEMDIGITSMANIFOLD Project and rotate an artificial data set of handwritten digits. 
% DEMGPSCOV2D Simple demonstration of sampling from a covariance function.
% DEMGPSAMPLE Simple demonstration of sampling from a covariance function.
% DEMMANIFOLD Visualise the manifold of the rotated 6 data.
% DEMMANIFOLDPRINT Print the principal components of the artificial digits data set.
% PREPDEMMANIFOLD Read in handwritten 6 and prepare for visualisation.
% DEMCOVFUNCSAMPLE Sample from some different covariance functions.
% DEMSTICKRESULTS1 Show the results of stick man optimisations interactively.
